use [master]
set nocount on 
go


declare
	--These must be set and they must be valid paths on the local SQL Server instance
	 @BackupFilePathSTATIC nvarchar(128)='J:\Backups'
	,@DataFilesLocation nvarchar(128)='J:\Test'
	--These must be set and they must be valid paths on the local SQL Server instance

	,@BackupFilePath nvarchar(128)=''
	,@BackupFile nvarchar(128)=''
	,@RESTOREFILELISTONLY nvarchar(128)=''
	,@RESTOREHEADERONLY nvarchar(128)=''
	,@RestoreCommand nvarchar(max)=''
	,@DatabaseName nvarchar(128)=''
	,@LogicalName nvarchar(128)=''
	,@PhysicalPathAndName nvarchar(128)=''
	,@PhysicalName nvarchar(128)=''
	,@ID int=0


if right(@BackupFilePathSTATIC, 1) <> '\'
	set @BackupFilePathSTATIC = @BackupFilePathSTATIC + '\'

if right(@DataFilesLocation, 1) <> '\'
	set @DataFilesLocation = @DataFilesLocation + '\'

 


if OBJECT_ID('BackupFileList') is not null
	drop table [BackupFileList]
if OBJECT_ID('RestoreFileList') is not null
	drop table [RestoreFileList]
if OBJECT_ID('RestoreHeaderOnly') is not null
	drop table [RestoreHeaderOnly]


create table [BackupFileList]
(
	 [ID] int identity(0,1)
	,[FileName] nvarchar(128)
)

create table [RestoreFileList]
(
	 [ID]					int identity(0,1)
	,[LogicalName]			nvarchar(128)
	,[PhysicalName]			nvarchar(260)
	,[Type]					char(1)
	,[FileGroupName]		nvarchar(128)
	,[Size]					numeric(20,0)
	,[MaxSize]				numeric(20,0)
	,[FileId]				bigint
	,[CreateLSN]			numeric(25,0)
	,[DropLSN]				numeric(25,0)		NULL
	,[UniqueId]				uniqueidentifier
	,[ReadOnlyLSN]			numeric(25,0)		NULL
	,[ReadWriteLSN]			numeric(25,0)		NULL
	,[BackupSizeInBytes]	bigint
	,[SourceBlockSize]		int
	,[FileGroupId]			int
	,[LogGroupGUID]			uniqueidentifier	NULL
	,[DifferentialBaseLSN]	numeric(25,0)		NULL
	,[DifferentialBaseGUID]	uniqueidentifier
	,[IsReadOnly]			bit
	,[IsPresent]			bit
	,[TDEThumbprint]		varbinary(32)
)

create table [RestoreHeaderOnly]
(
	 [BackupName]				nvarchar(128)
	,[BackupDescription]		nvarchar(255)
	,[BackupType]				smallint
	,[ExpirationDate]			datetime
	,[Compressed]				bit
	,[Position]					smallint
	,[DeviceType]				tinyint
	,[UserName]					nvarchar(128)
	,[ServerName]				nvarchar(128)
	,[DatabaseName]				nvarchar(128)
	,[DatabaseVersion]			int
	,[DatabaseCreationDate]		datetime
	,[BackupSize]				numeric(20,0)
	,[FirstLSN]					numeric(25,0)
	,[LastLSN]					numeric(25,0)
	,[CheckpointLSN]			numeric(25,0)
	,[DatabaseBackupLSN]		numeric(25,0)
	,[BackupStartDate]			datetime
	,[BackupFinishDate]			datetime
	,[SortOrder]				smallint
	,[CodePage]					smallint
	,[UnicodeLocaleId]			int
	,[UnicodeComparisonStyle]	int
	,[CompatibilityLevel]		tinyint
	,[SoftwareVendorId]			int
	,[SoftwareVersionMajor]		int
	,[SoftwareVersionMinor]		int
	,[SoftwareVersionBuild]		int
	,[MachineName]				nvarchar(128)
	,[Flags]					int
	,[BindingID]				uniqueidentifier
	,[RecoveryForkID]			uniqueidentifier
	,[Collation]				nvarchar(128)
	,[FamilyGUID]				uniqueidentifier
	,[HasBulkLoggedData]		bit
	,[IsSnapshot]				bit
	,[IsReadOnly]				bit
	,[IsSingleUser]				bit
	,[HasBackupChecksums]		bit
	,[IsDamaged]				bit
	,[BeginsLogChain]			bit
	,[HasIncompleteMetaData]	bit
	,[IsForceOffline]			bit
	,[IsCopyOnly]				bit
	,[FirstRecoveryForkID]		uniqueidentifier
	,[ForkPointLSN]				numeric(25,0)	NULL
	,[RecoveryModel]			nvarchar(60)
	,[DifferentialBaseLSN]		numeric(25,0)	NULL
	,[DifferentialBaseGUID]		uniqueidentifier
	,[BackupTypeDescription]	nvarchar(60)
	,[BackupSetGUID]			uniqueidentifier	NULL
	,[CompressedBackupSize]		bigint
	,[containment]				tinyint
)


INSERT INTO [BackupFileList] EXEC xp_cmdshell 'DIR /B J:\Backups\*.bak'
delete [BackupFileList] where [FileName] IS NULL

--select * from [BackupFileList]


--Prepare a restore statement for each backup file
while exists (select 1 from [BackupFileList])
begin

	SET @BackupFilePath = @BackupFilePathSTATIC

	select top 1 @BackupFile=[FileName] from [BackupFileList] order by [ID] asc
	set @BackupFilePath = @BackupFilePath + @BackupFile
	

	DELETE [RestoreFileList]
	DELETE [RestoreHeaderOnly]

	set @RESTOREFILELISTONLY = 'RESTORE FILELISTONLY FROM DISK = ''' + @BackupFilePath + ''''
	set @RESTOREHEADERONLY = 'RESTORE HEADERONLY FROM DISK = '''+ @BackupFilePath + ''''

	INSERT INTO [RestoreFileList] EXEC(@RESTOREFILELISTONLY)
	INSERT INTO [RestoreHeaderOnly] EXEC(@RESTOREHEADERONLY)

	--select * from [RestoreFileList]
	--select * from [RestoreHeaderOnly]

	select @DatabaseName = [DatabaseName] from [RestoreHeaderOnly]
	select @RestoreCommand = 'RESTORE DATABASE [' + @DatabaseName + '] FROM DISK=''' + @BackupFilePath + ''' WITH '

	
	
	--This will create the new path for the database files
	set @PhysicalPathAndName = @DataFilesLocation + @DatabaseName 
	EXEC master.sys.xp_create_subdir @PhysicalPathAndName


	while exists (select 1 from [RestoreFileList])
	begin

		select top 1 @ID=[ID], @LogicalName=[LogicalName], @PhysicalName = reverse(left(reverse([PhysicalName]), patindex('%\%', reverse([PhysicalName]))-1)) from [RestoreFileList] order by [ID] asc
		--select top 1 @ID=[ID], @LogicalName=[LogicalName], @PhysicalPathAndName =[PhysicalName] from [RestoreFileList] order by [ID] asc

		select @RestoreCommand = @RestoreCommand + 'MOVE ''' + @LogicalName + ''' TO ''' + @PhysicalPathAndName + '\' + @PhysicalName + ''',' + char(13)

		delete [RestoreFileList] where [ID]=@ID

	end

	select @RestoreCommand = @RestoreCommand + 'FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 1'

	print @RestoreCommand 

	delete [BackupFileList] where [FileName] = @BackupFile

end








--RESTORE DATABASE [DatabaseName] FROM DISK=@BackupFile
--WITH
--MOVE 'INT_OPS_30A_Batch_New'     TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\INT_OPS_30A_Batch_New.mdf',
--MOVE 'DBO_TRXN_MONTHDATA001_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA001_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA002_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA002_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA003_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA003_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA004_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA004_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA005_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA005_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA006_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA006_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA007_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA007_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA008_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA008_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA009_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA009_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA010_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA010_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA011_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA011_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA012_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA012_01.ndf',
--MOVE 'DBO_TRXN_MONTHDATA013_01'  TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\OPSBatch300\INT_OPS_30A_Batch_New\DBO_TRXN_MONTHDATA013_01.ndf',
--MOVE 'INT_OPS_30A_Batch_New_log' TO 'C:\SQL2008\MSSQL10_50.SQL2008\MSSQL\DATA\INT_OPS_30A_Batch_New_log.ldf'
--,FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 1


--EXECUTE master.sys.sp_MSforeachdb 'USE [?]; EXEC sp_spaceused'


SELECT d.name,
ROUND(SUM(mf.size) * 8 / 1024, 0) Size_MBs
FROM sys.master_files mf
INNER JOIN sys.databases d ON d.database_id = mf.database_id
WHERE d.database_id > 4 -- Skip system databases
GROUP BY d.name
ORDER BY Size_MBs, d.name


select @@servername as [Instance], SUM([Size_MBs])/1024.0 as [Size_GBs All DBs], (SUM([Size_MBs])/1024.0)*(.33) as [Size_GBs All Compressed Backups] from
(
SELECT d.name,
ROUND(SUM(mf.size) * 8 / 1024, 0) Size_MBs
FROM sys.master_files mf
INNER JOIN sys.databases d ON d.database_id = mf.database_id
WHERE d.database_id > 4 -- Skip system databases
GROUP BY d.name
) a






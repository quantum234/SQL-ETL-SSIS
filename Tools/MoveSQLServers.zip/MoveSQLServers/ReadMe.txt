0.  Copy this folder, MoveSQLServers, somewhere on the server you are transferring.
1.  Run AllDatabaseSizes.sql to get an idea of what you are backing up and make sure you have enough space
2.  Run BackupAllDatabases.sql to backup all databases.  If you want to only get the backup statements and not actually run the backups, just comment out the BACKUP DATABASE @database... line.
3.  Run the CreateTransferLoginsProcs.sql script to create the SPs necessary to trasnfer the logins
4.  Run the trasnfer logins SP by executing EXEC master..sp_help_revlogin
5.  Take this output, paste it in a new query windows and save the file in the output folder.
6.  On SSMS hit F7 to view the Object Explorer Details
7.  Click on the SQL Server Agent > Operators, select all the operators and script them to a new query window and save it to the output folder
8.  Click on SQL Server Agent > Jobs, select all the jobs and script them to a new query window and save it to the output folder
9.  Click on the Server Objects > Linked Servers, select all the linked serversand script them to a new query window and save it to the output folder

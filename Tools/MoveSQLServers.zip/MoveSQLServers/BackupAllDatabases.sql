USE [master]
SET NOCOUNT ON
GO


declare
	 @backuppath	nvarchar(128)='J:\Backups\'
	,@server		nvarchar(128)=(select @@servername)
	,@database		nvarchar(128)=''
	,@backupfile	nvarchar(128)=''
	,@backupname	nvarchar(500)=''

if object_id('tblDataBases') is not null
	drop table [tblDataBases]

create table [tblDataBases] ([name] nvarchar(128), [backupfile] nvarchar(500), [backupname] nvarchar(500) CONSTRAINT [PK_tblDataBases] PRIMARY KEY CLUSTERED ([name] ASC)) ON [PRIMARY]

if right(@backuppath,1)<>'\'
	set @backuppath = @backuppath + '\'


insert into [tblDataBases]
select [name], @backuppath + replace(@@SERVERNAME,'\','_') + '_' + [name] + '_' + convert(varchar(10), getdate(), 112) + '_' + replace(convert(varchar(10), getdate(), 108),':','') + '.bak' as [backupfile], replace(@@SERVERNAME,'\','_') + '_' + [name] + '_' + convert(varchar(10), getdate(), 112) + '_' + replace(convert(varchar(10), getdate(), 108),':','') + N'-Full Database Backup' as [backupname]
from sys.databases
where database_id > 4
order by [name]

while exists (select 1 from [tblDataBases])
begin 

	select top 1 @database = [name], @backupfile = [backupfile], @backupname = [backupname] from [tblDataBases]

	print 'BACKUP DATABASE [' + @database + '] TO DISK=''' + @backupfile + ''' WITH NOFORMAT , INIT, NAME=''' + @backupname + ''', SKIP, NOREWIND, NOUNLOAD, COMPRESSION, STATS=1'
	BACKUP DATABASE @database TO DISK = @backupfile WITH NOFORMAT, INIT, NAME = @backupname, SKIP, NOREWIND, NOUNLOAD, COMPRESSION, STATS=1

	delete [tblDataBases] where [name]=@database

end

GO


